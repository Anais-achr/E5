package fr.umlv.smalljs.stackinterp;

import fr.umlv.smalljs.rt.Failure;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;

import static fr.umlv.smalljs.ast.ASTBuilder.createScript;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class StackInterpreterTests {
  private static String execute(String code) {
    var script = createScript(code);
    var outStream = new ByteArrayOutputStream(8192);
    StackInterpreter.interpret(script, new PrintStream(outStream, false, StandardCharsets.UTF_8));
    return outStream.toString(StandardCharsets.UTF_8).replace("\r\n", "\n");
  }

  @Nested
  //@Disabled("Q2")
  public class Q2 {
    @Test
    public void helloDoubleQuotedString() {
      assertEquals("", execute("""
              "hello"
              """));
    }

    @Test
    public void helloSingleQuotedString() {
      assertEquals("", execute("""
              'hello'
              """));
    }

    @Test
    public void severalLiterals() {
      assertEquals("", execute("""
              "a"
              'b'
              "c"
              """));
    }
  }

  @Nested
  //@Disabled("Q3")
  public class Q3 {
    @Test
    public void integer3() {
      assertEquals("", execute("""
              3
              """));
    }

    @Test
    public void severalIntegers() {
      assertEquals("", execute("""
              0
              42
              1000000
              """));
    }
  }

  @Nested
  //@Disabled("Q4")
  public class Q4 {
    @Test
    public void print() {
      assertEquals("hello\n", execute("print(\"hello\")\n"));
      assertEquals("foobar\n", execute("print('foobar')\n"));
      assertEquals("3\n", execute("print(3)\n"));
      assertEquals("undefined\n", execute("print(undefined)\n"));
    }

    @Test
    public void printNoArgument() {
      assertEquals("\n", execute("print()\n"));
    }

    @Test
    public void printSeveralArguments() {
      assertEquals("hello Bob 3\n", execute("print('hello', 'Bob', 3)\n"));
    }

    @Test
    public void printSeveralTimes() {
      assertEquals("a\nb\n", execute("""
              print('a')
              print('b')
              """));
    }
  }

  @Nested
  //@Disabled("Q5")
  public class Q5 {
    @Test
    public void printPrint() {
      var output = execute("print(print)\n");
      assertTrue(output.startsWith("{ // function print\n"), output);
    }
  }

  @Nested
  //@Disabled("Q6")
  public class Q6 {
    @Test
    public void printOperations() {
      assertEquals("5\n", execute("print(3 + 2)\n"));
      assertEquals("1\n", execute("print(3 - 2)\n"));
      assertEquals("6\n", execute("print(3 * 2)\n"));
      assertEquals("1\n", execute("print(3 / 2)\n"));
    }

    @Test
    public void printModulo() {
      assertEquals("1\n", execute("print(7 % 3)\n"));
    }

    @Test
    public void printComparisons() {
      assertEquals("1\n", execute("print(2 < 3)\n"));
      assertEquals("0\n", execute("print(3 < 2)\n"));
      assertEquals("1\n", execute("print(3 == 3)\n"));
      assertEquals("0\n", execute("print(3 != 3)\n"));
    }

    @Test
    public void printNestedOperations() {
      assertEquals("7\n", execute("print(1 + 2 * 3)\n"));
    }

    @Test
    public void callUnknownFunction() {
      assertThrows(Failure.class, () -> execute("foo(1)\n"));
    }
  }


  @Nested
  //@Disabled("Q7")
  public class Q7 {
    @Test
    public void printPrint3() {
      assertEquals("3\nundefined\n", execute("print(print(3))\n"));
    }

    @Test
    public void printPrintPrint() {
      assertEquals("3\nundefined\nundefined\n", execute("print(print(print(3)))\n"));
    }

    @Test
    public void argumentsAreEvaluatedLeftToRightBeforeTheCall() {
      assertEquals("1\n2\nundefined undefined\n", execute("print(print(1), print(2))\n"));
    }
  }


  @Nested
  //@Disabled("Q8")
  public class Q8 {
    @Test
    public void printAVariable() {
      assertEquals("3\n", execute("""
              var a = 3;
              print(a);
              """));
    }

    @Test
    public void printSeveralVariables() {
      assertEquals("7\n", execute("""
              var a = 3;
              var b = 4;
              print(a + b);
              """));
    }

    @Test
    public void printNoVariable() {
      assertThrows(Failure.class, () -> execute("""
              print(a);
              """));
    }

    @Test
    public void printAssignmentNoVariable() {
      assertThrows(Failure.class, () -> execute("""
              a = 3;
              """));
    }

    @Test
    public void printSeveralAssignments() {
      assertEquals("42\n42\n", execute("""
              var a = 42;
              var b = a;
              print(a);
              print(b);
              """));
    }

    @Test
    public void printSeveralArguments() {
      assertEquals("hello Bob\n", execute("""
              var me = 'Bob';
              print('hello', me);
              """));
    }

    @Test
    public void reassignAVariable() {
      assertEquals("1\n2\n", execute("""
              var a = 1;
              print(a);
              a = 2;
              print(a);
              """));
    }

    @Test
    public void declareFromAnExpression() {
      assertEquals("5\n", execute("""
              var a = 2;
              var b = a + 3;
              print(b);
              """));
    }
  }


  @Nested
  //@Disabled("Q9")
  public class Q9 {
    @Test
    public void printAVariableDefinedAfter() {
      assertEquals("undefined\n", execute("print(a);\nvar a = 2;\n"));
    }

    @Test
    public void readBeforeAndAfterTheDeclaration() {
      assertEquals("undefined\n2\n", execute("""
              print(a);
              var a = 2;
              print(a);
              """));
    }

    @Test
    public void declareTwice() {
      assertEquals("2\n", execute("""
              var a = 1;
              var a = 2;
              print(a);
              """));
    }
  }


  @Nested
  @Disabled("Q10")
  public class Q10 {
    @Test
    public void callAUserDefinedFunctionAndPrint() {
      assertEquals("3\n", execute("""
              function foo(x) {
                return x + 1;
              }
              print(foo(2));
              """));
    }

    @Test
    public void callAFunctionThatReturnUndefinedAndPrint() {
      assertEquals("undefined\n", execute("""
              function foo() {
                return;
              }
              print(foo());
              """));
    }

    @Test
    public void callAUserDefinedFunctionWithTheWrongNumberOfArguments() {
      assertThrows(Failure.class, () -> execute("""
              function foo(a, b) {
              }
              print(foo(2));
              """));
    }

    @Test
    public void callAUserDefinedFunctionWithTooManyArguments() {
      assertThrows(Failure.class, () -> execute("""
              function foo(a) {
              }
              foo(1, 2);
              """));
    }

    @Test
    public void callSeveralFunctions() {
      assertEquals("foo\nbar\n", execute("""
              function foo() {
                print('foo');
                bar();
              }
              function bar() {
                print('bar');
              }
              foo();
              """));
    }

    @Test
    public void callVariableFunction() {
      assertEquals("6\n", execute("""
              var foo = function bar(x) {
                return x * 2;}
              print(foo(3));
              """));
    }

    @Test
    public void callVariableFunction2() {
      assertEquals("6\n", execute("""
              var foo = function (x) {
                return x * 2;}
              print(foo(3));
              """));
    }

    @Test
    public void callFunctionWithNoReturn() {
      assertEquals("undefined\n", execute("""
              function undef() { }
              print(undef());
              """));
    }

    @Test
    public void parameterDoesNotOverwriteGlobal() {
      assertEquals("1\n10\n", execute("""
              var x = 10;
              function f(x) { return x; }
              print(f(1));
              print(x);
              """));
    }

    @Test
    public void localVariableDoesNotLeak() {
      assertThrows(Failure.class, () -> execute("""
              function f() {
                var x = 1;
                return x;
              }
              print(f());
              print(x);
              """));
    }

    @Test
    public void thisIsUndefinedInAFunction() {
      assertEquals("undefined\n", execute("""
              function f() { return this; }
              print(f());
              """));
    }
  }


  @Nested
  //@Disabled("Q11")
  public class Q11 {
    @Test
    public void printWithAnIf() {
      assertEquals("false\n", execute("""
              var a = 2;
              if (a == 3) {
                print("true");
              } else {
                print("false");
              }
              """));
    }

    @Test
    public void printWithAnIf2() {
      assertEquals("true\n", execute("""
              var a = 3;
              if (a == 3) {
                print("true");
              } else {
                print("false");
              }
              """));
    }

    @Test
    public void printVariableWeirdScope() {
      assertEquals("false\nundefined\n", execute("""
              var a = 2;
              if (a == 3) {
                print("true");
                var b = 'hello';
              } else {
                print("false");
              }
              print(b);"""));
    }

    @Test
    public void printVariableWeirdScope2() {
      assertEquals("true\nhello\n", execute("""
              var a = 3;
              if (a == 3) {
                print("true");
                var b = 'hello';
              } else {
                print("false");
              }
              print(b);"""));
    }

    @Test
    public void callAUserDefinedFunctionWithAnIf() {
      assertEquals("0\n7\n", execute("""
              function f(x) {
                  if (x < 3) {
                    return 0;
                  } else {
                    return x;
                  }
              }
              print(f(2));
              print(f(7));
              """));
    }

    @Test
    public void callAUserDefinedFunctionWithAnIfAndAVariable() {
      assertEquals("0\n7\n", execute("""
              function f(x) {
                  if (x < 3) {
                    var a = 0;
                  } else {
                    var a = x;
                  }
                  return a;
              }
              print(f(2));
              print(f(7));
              """));
    }

    @Test
    public void ifOnAComparisonResult() {
      assertEquals("yes\nno\n", execute("""
              if (2 < 3) { print("yes"); } else { print("no"); }
              if (3 < 2) { print("yes"); } else { print("no"); }
              """));
    }
  }


  @Nested
  //@Disabled("Q12")
  public class Q12 {
    @Test
    public void callFibo() {
      assertEquals("21\n", execute("""
              function fibo(n) {
                  if (n < 2) {
                    return 1
                  } else {
                    return fibo(n - 1) + fibo(n - 2)
                  }
                }

              print(fibo(7))
              """));
    }

    @Test
    public void callRecursiveFunction() {
      assertEquals("24\n", execute("""
              function fact(n) {
                if (n < 1) {
                  return 1;
                } else {
                  return n * fact(n - 1);
                }
              }
              print(fact(4));
              """));
    }

    @Test
    public void callSeveralOperations() {
      assertEquals("5\n-1\n6\n0\n", execute("""
              function add(a, b) { return a + b; }
              function sub(a, b) { return a - b; }
              function mul(a, b) { return a * b; }
              function div(a, b) { return a / b; }
              
              function calc(f, a, b) {
                return f(a, b);
              }
              print(calc(add, 2, 3));
              print(calc(sub, 2, 3));
              print(calc(mul, 2, 3));
              print(calc(div, 2, 3));
              """));
    }

    @Test
    public void callAndRewrite() {
      assertEquals("2\n9\n", execute("""
              function f() { return op(); }
              function op() { return 2; }
              print(f());
              function op() { return 9; }
              print(f());
              """));
    }

    @Test
    public void mutualRecursion() {
      assertEquals("1\n0\n", execute("""
              function even(n) {
                if (n == 0) { return 1; } else { return odd(n - 1); }
              }
              function odd(n) {
                if (n == 0) { return 0; } else { return even(n - 1); }
              }
              print(even(10));
              print(even(7));
              """));
    }
  }


  @Nested
  //@Disabled("Q13")
  public class Q13 {
    @Test
    public void createAnObject() {
      assertEquals("""
              { // object
                x: 1
                y: 2
                proto: null
              }
              """,
          execute("""
                  var o = {
                      x: 1,
                      y: 2
                  };
                  print(o);
                  """));
    }

    @Test
    public void createAnEmptyObject() {
      assertEquals("""
              { // object
                proto: null
              }
              """,
          execute("""
                  var o = { };
                  print(o);
                  """));
    }

    @Test
    public void createAnObjectWithAString() {
      assertEquals("""
              { // object
                name: Bob
                proto: null
              }
              """,
          execute("""
                  var o = { name: "Bob" };
                  print(o);
                  """));
    }

    @Test
    public void createAnObjectKeepsTheFieldOrder() {
      assertEquals("""
              { // object
                z: 3
                y: 2
                x: 1
                proto: null
              }
              """,
          execute("""
                  var o = { z: 3, y: 2, x: 1 };
                  print(o);
                  """));
    }
  }


  @Nested
  @Disabled("Q14")
  public class Q14 {
    @Test
    public void createAnObjectFromAVariableValue() {
      assertEquals("""
              { // object
                x: 1
                y: 2
                proto: null
              }
              """,
          execute("""
                  var a = 1;
                  var o = {
                    x: a,
                    y: a + 1
                  }
                  print(o);
                  """));
    }

    @Test
    public void createAnObjectEvaluationOrder() {
      assertEquals(
          "a\nb\n",
          execute("""
                  var foo = {
                    a: print('a'),
                    b: print('b')
                  };"""));
    }

    @Test
    public void createAnObjectFromFunctionCalls() {
      assertEquals("""
              { // object
                x: 1
                y: 2
                proto: null
              }
              """,
          execute("""
                  function one() { return 1; }
                  var o = {
                    x: one(),
                    y: one() + 1
                  };
                  print(o);
                  """));
    }
  }


  @Nested
  @Disabled("Q15")
  public class Q15 {
    @Test
    public void readAField() {
      assertEquals("John\n", execute("""
              var john = { name: "John" };
              print(john.name);
              """));
    }

    @Test
    public void readSeveralFields() {
      assertEquals("1 2\n", execute("""
              var p = { x: 1, y: 2 };
              print(p.x, p.y);
              """));
    }

    @Test
    public void readANestedField() {
      assertEquals("5\n", execute("""
              var o = { p: { x: 5 } };
              print(o.p.x);
              """));
    }

    @Test
    public void objectGetAFieldNoValue() {
      assertEquals(
          "undefined\n",
          execute("""
                  var john = { name: "John" };
                  print(john.foo);
                  """));
    }

    @Test
    public void readSameFieldOnSeveralObjects() {
      assertEquals(
          "3\n7\n",
          execute("""
                  function fun(o) {
                    return o.field;
                  }
                  var object = {
                    field: 3,
                    toto: 0
                  };
                  var object2 = {
                    field: 7,
                    toto: 4
                  };
                  print(fun(object));
                  print(fun(object2));
                  """));
    }
  }

  @Nested
  @Disabled("Q16")
  public class Q16 {
    @Test
    public void objectUpdateAFieldValue() {
      assertEquals(
          "Jane\n",
          execute("""
                  var john = { name: "John" };
                  john.name = "Jane";
                  print(john.name);
                  """));
    }

    @Test
    public void objectGetAndSetAField() {
      assertEquals(
          "2\n9\n",
          execute("""
                  function f(o) { return o.field; }
                  var obj = { field: 2 };
                  print(f(obj));
                  obj.field = 9;
                  print(f(obj));
                  """));
    }

    @Test
    public void writeDoesNotAffectOtherObjects() {
      assertEquals("2 1\n", execute("""
              var a = { x: 1 };
              var b = { x: 1 };
              a.x = 2;
              print(a.x, b.x);
              """));
    }

    @Test
    public void writeAFieldOfUndefined() {
      assertThrows(Failure.class, () -> execute("""
              var o = { };
              o.a.b = 2;
              """));
    }
  }


  @Nested
  @Disabled("Q17")
  public class Q17 {
    @Test
    public void objectCallAMethod() {
      assertEquals(
          "hello 42\nhello 42\n",
          execute("""
                  var object = {
                    bar: "hello",
                    foo: function(x) {
                           print(this.bar, x);
                         }
                  };
                  object.foo(42);
                  object.foo(42);
                  """));
    }

    @Test
    public void callAMethodWithAResult() {
      assertEquals("15\n", execute("""
              var calc = {
                base: 10,
                add: function(x) { return this.base + x; }
              };
              print(calc.add(5));
              """));
    }

    @Test
    public void callAMethodThatUpdatesThis() {
      assertEquals("2\n", execute("""
              var counter = {
                value: 0,
                inc: function() { this.value = this.value + 1; }
              };
              counter.inc();
              counter.inc();
              print(counter.value);
              """));
    }

    @Test
    public void thisIsTheReceiver() {
      assertEquals("a b\n", execute("""
              function who() { return this.name; }
              var a = { name: "a", who: who };
              var b = { name: "b", who: who };
              print(a.who(), b.who());
              """));
    }

    @Test
    public void receiverIsEvaluatedOnce() {
      assertEquals("make\n1\n", execute("""
              function make() {
                print("make");
                return { f: function() { return 1; } };
              }
              print(make().f());
              """));
    }

    @Test
    public void callAFieldThatIsNotAFunction() {
      assertThrows(Failure.class, () -> execute("""
              var o = { x: 1 };
              o.x();
              """));
    }
  }
}