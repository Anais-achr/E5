#! /bin/sh

nvcc -o mandelbrot -O2 mandelbrot.cu --library=SDL2
